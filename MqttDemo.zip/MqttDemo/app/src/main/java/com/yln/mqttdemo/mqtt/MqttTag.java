package com.yln.mqttdemo.mqtt;

/**
 * Created by yellowRifle on 2019/5/12.
 */

public class MqttTag {
    public final static int MQTT_STATE_CONNECTED=1;
    public final static int MQTT_STATE_LOST=2;
    public final static int MQTT_STATE_FAIL=3;
    public final static int MQTT_STATE_RECEIVE=4;
    public final static int MQTT_STATE_SEND_SUCC=5;
}
