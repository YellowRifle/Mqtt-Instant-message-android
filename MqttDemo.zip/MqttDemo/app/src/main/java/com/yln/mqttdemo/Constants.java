package com.yln.mqttdemo;

public class Constants {
    public static final String MQTT_IP="206.253.164.235";//服务器地址
    public static final String MQTT_PORT="1883";//服务器端口
    public static final String MQTT_TOPIC="mqtt";//订阅主题
    public static final String MQTT_USERNAME="xiaomi";//用户名
    public static final String MQTT_USERID="11";//用户id
}
